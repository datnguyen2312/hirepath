from flask import Flask, render_template, request, redirect, url_for, jsonify
import json

app = Flask(__name__)

vendors = []
contracts = []


def seed_vendors():
    return [
        {"vendor_name": "MedLine Industries", "item_name": "Surgical Gloves (M)", "item_category": "PPE", "country": "USA", "unit_cost": 0.18, "previous_cost": 0.14, "lead_time": 7, "delivery_status": "On Time", "moq": 10000, "backup_vendor": "Yes", "backup_vendor_name": "Cardinal Health", "quality_issue": "No", "annual_spend": 124000, "affected_departments": 6, "facility": "St. Mercy General", "owner": "Sarah Okafor", "contract_expiry": "2026-12-31", "certifications": "FDA 510(k), ISO 13485", "capacity_fit": "High", "qualification_stage": "Approved", "region_risk": "Low", "formulary_status": "Approved"},
        {"vendor_name": "B. Braun Medical", "item_name": "IV Saline 0.9% 1L", "item_category": "IV Solutions", "country": "Germany", "unit_cost": 2.45, "previous_cost": 1.98, "lead_time": 21, "delivery_status": "Delayed", "moq": 2000, "backup_vendor": "No", "backup_vendor_name": "", "quality_issue": "Yes", "annual_spend": 310000, "affected_departments": 12, "facility": "All Facilities", "owner": "Procurement Committee", "contract_expiry": "2026-06-30", "certifications": "ISO 13485, CE Mark", "capacity_fit": "Medium", "qualification_stage": "Review", "region_risk": "Medium", "formulary_status": "Critical"},
        {"vendor_name": "Becton Dickinson", "item_name": "BD Vacutainer Tubes", "item_category": "Lab Supplies", "country": "USA", "unit_cost": 0.54, "previous_cost": 0.50, "lead_time": 10, "delivery_status": "On Time", "moq": 5000, "backup_vendor": "Yes", "backup_vendor_name": "Greiner Bio-One", "quality_issue": "No", "annual_spend": 87000, "affected_departments": 4, "facility": "Regional Lab Hub", "owner": "Lab Manager", "contract_expiry": "2027-03-15", "certifications": "FDA 510(k), ISO 13485", "capacity_fit": "High", "qualification_stage": "Approved", "region_risk": "Low", "formulary_status": "Approved"},
        {"vendor_name": "Stryker Corp.", "item_name": "Hip Implant System", "item_category": "Implants & Devices", "country": "USA", "unit_cost": 4200.00, "previous_cost": 3950.00, "lead_time": 30, "delivery_status": "On Time", "moq": 5, "backup_vendor": "Yes", "backup_vendor_name": "Zimmer Biomet", "quality_issue": "No", "annual_spend": 756000, "affected_departments": 2, "facility": "Orthopedic Center", "owner": "Surgical Director", "contract_expiry": "2027-09-01", "certifications": "FDA PMA, ISO 13485, MDR", "capacity_fit": "High", "qualification_stage": "Approved", "region_risk": "Low", "formulary_status": "Approved"},
        {"vendor_name": "Owens & Minor", "item_name": "Sterile Drape Pack", "item_category": "Surgical Supplies", "country": "USA", "unit_cost": 12.75, "previous_cost": 11.40, "lead_time": 14, "delivery_status": "On Time", "moq": 500, "backup_vendor": "No", "backup_vendor_name": "", "quality_issue": "No", "annual_spend": 198000, "affected_departments": 5, "facility": "Main OR Suite", "owner": "OR Supply Chain", "contract_expiry": "2026-08-20", "certifications": "ISO 13485, BRCGS", "capacity_fit": "Medium", "qualification_stage": "Sampling", "region_risk": "Low", "formulary_status": "Preferred"},
        {"vendor_name": "Fresenius Kabi", "item_name": "Propofol 200mg/20mL", "item_category": "Pharmaceuticals", "country": "Austria", "unit_cost": 8.90, "previous_cost": 7.20, "lead_time": 28, "delivery_status": "Delayed", "moq": 1200, "backup_vendor": "No", "backup_vendor_name": "", "quality_issue": "No", "annual_spend": 215000, "affected_departments": 8, "facility": "ICU & OR", "owner": "Pharmacy Director", "contract_expiry": "2026-05-01", "certifications": "FDA ANDA, GMP, EMA", "capacity_fit": "Medium", "qualification_stage": "Approved", "region_risk": "High", "formulary_status": "Critical"},
        {"vendor_name": "Philips Healthcare", "item_name": "Patient Monitor PM10", "item_category": "Capital Equipment", "country": "Netherlands", "unit_cost": 14500.00, "previous_cost": 13800.00, "lead_time": 45, "delivery_status": "On Time", "moq": 1, "backup_vendor": "Yes", "backup_vendor_name": "GE Healthcare", "quality_issue": "No", "annual_spend": 435000, "affected_departments": 10, "facility": "ICU / Step-Down Units", "owner": "Clinical Engineering", "contract_expiry": "2028-01-01", "certifications": "FDA 510(k), IEC 60601, CE", "capacity_fit": "High", "qualification_stage": "Approved", "region_risk": "Low", "formulary_status": "Approved"},
        {"vendor_name": "Medivance Linen", "item_name": "Reusable Patient Gown", "item_category": "Linen & Textiles", "country": "Mexico", "unit_cost": 3.20, "previous_cost": 2.95, "lead_time": 18, "delivery_status": "On Time", "moq": 2000, "backup_vendor": "Yes", "backup_vendor_name": "AmeriPride", "quality_issue": "No", "annual_spend": 46000, "affected_departments": 15, "facility": "All Wards", "owner": "EVS Manager", "contract_expiry": "2026-10-31", "certifications": "Oeko-Tex, ASTM F1671", "capacity_fit": "High", "qualification_stage": "Approved", "region_risk": "Low", "formulary_status": "Approved"},
    ]


def seed_contracts():
    return [
        {"vendor_name": "MedLine Industries", "item_name": "Surgical Gloves", "contract_status": "Active", "contracted_cost": 0.17, "contracted_lead": 7, "gpo_aligned": "Yes"},
        {"vendor_name": "B. Braun Medical", "item_name": "IV Saline", "contract_status": "Under Review", "contracted_cost": 2.30, "contracted_lead": 19, "gpo_aligned": "No"},
        {"vendor_name": "Fresenius Kabi", "item_name": "Propofol", "contract_status": "Expiring Soon", "contracted_cost": 8.50, "contracted_lead": 26, "gpo_aligned": "Yes"},
        {"vendor_name": "Owens & Minor", "item_name": "Sterile Drape Pack", "contract_status": "Active", "contracted_cost": 12.00, "contracted_lead": 13, "gpo_aligned": "No"},
    ]


def ensure_seeded():
    global vendors, contracts
    if not vendors:
        vendors = seed_vendors()
    if not contracts:
        contracts = seed_contracts()


def enrich(item):
    x = dict(item)
    x["cost_change"] = round(x["unit_cost"] - x["previous_cost"], 2)

    risk = 0
    if x["delivery_status"] == "Delayed": risk += 40
    if x["lead_time"] > 25: risk += 25
    elif 15 <= x["lead_time"] <= 25: risk += 12
    if x["formulary_status"] == "Critical": risk += 20
    if x["cost_change"] > 0.50: risk += 10
    if x["backup_vendor"] == "No": risk += 20
    if x["quality_issue"] == "Yes": risk += 25
    if x["moq"] >= 5000: risk += 8
    if x["region_risk"] == "Medium": risk += 8
    elif x["region_risk"] == "High": risk += 18

    if risk >= 55: x["risk_level"] = "High"; x["vendor_tier"] = "Critical"
    elif risk >= 28: x["risk_level"] = "Medium"; x["vendor_tier"] = "Watchlist"
    else: x["risk_level"] = "Low"; x["vendor_tier"] = "Preferred"

    fit = 0
    fit += 25 if x["capacity_fit"] == "High" else 15 if x["capacity_fit"] == "Medium" else 8
    fit += 20 if x["lead_time"] <= 14 else 12 if x["lead_time"] <= 25 else 6
    fit += 15 if x["backup_vendor"] == "Yes" else 5
    fit += 12 if x["quality_issue"] == "No" else 0
    fit += 10 if x["qualification_stage"] in {"Approved", "Sampling"} else 5
    fit += 10 if x["formulary_status"] in {"Approved", "Preferred"} else 5
    fit += 8 if x["region_risk"] == "Low" else 4 if x["region_risk"] == "Medium" else 0
    x["fit_score"] = fit

    x["landed_cost"] = round(x["unit_cost"] * 1.09, 4)
    x["cert_count"] = len([c for c in x["certifications"].split(",") if c.strip()])
    return x


def get_vendors():
    ensure_seeded()
    return [enrich(x) for x in vendors]


def get_contracts():
    ensure_seeded()
    return list(contracts)


def apply_filters(data, args):
    search = args.get("search", "").strip().lower()
    category = args.get("category", "")
    risk = args.get("risk", "")
    country = args.get("country", "")
    stage = args.get("stage", "")
    result = data
    if search:
        result = [x for x in result if search in x["vendor_name"].lower() or search in x["item_name"].lower() or search in x["facility"].lower()]
    if category:
        result = [x for x in result if x["item_category"] == category]
    if risk:
        result = [x for x in result if x["risk_level"] == risk]
    if country:
        result = [x for x in result if x["country"] == country]
    if stage:
        result = [x for x in result if x["qualification_stage"] == stage]
    return result


def build_summary(data):
    total = len(data)
    high = sum(1 for x in data if x["risk_level"] == "High")
    backups_needed = sum(1 for x in data if x["backup_vendor"] == "No")
    critical_formulary = sum(1 for x in data if x["formulary_status"] == "Critical")
    savings = round(sum(max(x["cost_change"], 0) * x["moq"] for x in data), 0)
    expiring_soon = sum(1 for x in data if x["qualification_stage"] in {"Review", "Sampling"})
    compliance = max(0, min(100, round(100 - (high / max(total, 1)) * 40 - (backups_needed / max(total, 1)) * 30)))
    return {
        "total_vendors": total, "high_risk": high, "backups_needed": backups_needed,
        "critical_formulary": critical_formulary, "potential_savings": savings,
        "expiring_soon": expiring_soon, "compliance_score": compliance
    }


def build_exec_story(summary):
    return (
        f"{summary['high_risk']} vendors are currently high risk and {summary['critical_formulary']} critical formulary items face supply exposure. "
        f"{summary['backups_needed']} item lanes have no approved backup vendor. "
        f"Supply chain compliance is estimated at {summary['compliance_score']}%, with ${summary['potential_savings']:,.0f} in cost-reduction opportunity identified."
    )


def build_chart_data(data):
    categories = {}
    countries = {}
    for x in data:
        categories.setdefault(x["item_category"], 0)
        categories[x["item_category"]] += x["annual_spend"]
        countries.setdefault(x["country"], 0)
        countries[x["country"]] += 1
    shortlist = sorted(data, key=lambda z: z["fit_score"], reverse=True)[:6]
    return {
        "category_labels": list(categories.keys()),
        "category_spend": list(categories.values()),
        "fit_labels": [x["vendor_name"] for x in shortlist],
        "fit_values": [x["fit_score"] for x in shortlist],
        "country_labels": list(countries.keys()),
        "country_values": list(countries.values()),
    }


def build_vendor_cards(data):
    rows = []
    for x in sorted(data, key=lambda z: z["fit_score"], reverse=True):
        rec = "Strong supply partner" if x["backup_vendor"] == "Yes" and x["risk_level"] == "Low" else "Needs backup qualification" if x["risk_level"] == "Medium" else "Immediate risk mitigation needed"
        rows.append({"vendor_name": x["vendor_name"], "item_name": x["item_name"], "category": x["item_category"], "country": x["country"], "fit_score": x["fit_score"], "lead_time": x["lead_time"], "unit_cost": x["unit_cost"], "recommendation": rec, "certifications": x["certifications"], "formulary_status": x["formulary_status"]})
    return rows


def build_pipeline(data):
    stages = ["New", "Contacted", "Quoting", "Sampling", "Review", "Approved", "Rejected"]
    out = {stage: [] for stage in stages}
    for x in data:
        out.setdefault(x["qualification_stage"], []).append(x)
    return out


def build_planning_data(data):
    if not data:
        return {"kpis": {"forecast_accuracy": 0, "stockout_risk": "Low", "fill_rate": 0, "constrained_months": 0}, "months": [], "demand": [], "supply": [], "safety_stock": [], "plans": [], "actions": []}

    total_spend = sum(x["annual_spend"] for x in data)
    base_monthly = max(80, round(total_spend / 12 / 1000))
    seasonal = [1.02, 1.05, 1.08, 1.14, 1.10, 1.06]
    months = ["May", "Jun", "Jul", "Aug", "Sep", "Oct"]
    demand = [round(base_monthly * m) for m in seasonal]
    delay_penalty = sum(1 for x in data if x["delivery_status"] == "Delayed")
    no_backup_count = sum(1 for x in data if x["backup_vendor"] == "No")
    supply = [round(v * (0.96 - delay_penalty * 0.03 - no_backup_count * 0.01 + (0.01 if i >= 3 else 0))) for i, v in enumerate(demand)]
    safety_stock = [round(v * 0.12) for v in demand]
    constrained = sum(1 for d, s in zip(demand, supply) if s < d)
    forecast_accuracy = max(74, min(96, round(91 - delay_penalty * 2 - no_backup_count * 1.5)))
    fill_rate = max(85, min(99, round(97 - delay_penalty * 2 - constrained * 1.5)))
    stockout_risk = "High" if constrained >= 3 else "Medium" if constrained >= 1 else "Low"
    ranked = sorted(data, key=lambda x: (x["affected_departments"], x["annual_spend"]), reverse=True)[:4]
    plans = []
    for x in ranked:
        d_val = max(100, round(x["annual_spend"] / 1000 * 1.2))
        s_val = round(d_val * (0.87 if x["risk_level"] == "High" else 0.95 if x["risk_level"] == "Medium" else 1.01))
        gap = d_val - s_val
        plans.append({"item": x["item_name"], "facility": x["facility"], "owner": x["owner"], "demand": d_val, "supply": s_val, "gap": gap, "status": "Expedite / source alternative" if gap > 15 else "Monitor" if gap > 0 else "Covered"})
    actions = [
        f"Activate emergency stockpile protocol for {no_backup_count} single-source critical item(s) before next demand cycle.",
        f"Escalate {delay_penalty} delayed vendor lane(s) to supplier relationship review within 72 hours.",
        f"Coordinate with GPO on contract alignment for {constrained} constrained supply month(s) flagged in the demand plan.",
        f"Achieve target fill rate of ≥98% by resolving supply gaps in high-acuity departments before peak season.",
    ]
    return {"kpis": {"forecast_accuracy": forecast_accuracy, "stockout_risk": stockout_risk, "fill_rate": fill_rate, "constrained_months": constrained}, "months": months, "demand": demand, "supply": supply, "safety_stock": safety_stock, "plans": plans, "actions": actions}


def build_insights(data):
    if not data:
        return {"cert_ready": 0, "qa_flags": 0, "dept_risk": [], "single_source": 0, "avg_fit": 0, "critical_items": 0, "contract_ready": 0}
    cert_ready = sum(1 for x in data if x["cert_count"] >= 2)
    dept_risk = sorted(data, key=lambda x: (x["affected_departments"], x["risk_level"] == "High"), reverse=True)[:3]
    qa_flags = sum(1 for x in data if x["quality_issue"] == "Yes")
    single_source = sum(1 for x in data if x["backup_vendor"] == "No")
    avg_fit = round(sum(x["fit_score"] for x in data) / max(len(data), 1))
    critical_items = sum(1 for x in data if x["formulary_status"] == "Critical")
    contract_ready = sum(1 for x in data if x["qualification_stage"] in {"Contacted", "Quoting", "Sampling", "Review"})
    return {"cert_ready": cert_ready, "qa_flags": qa_flags, "dept_risk": dept_risk, "single_source": single_source, "avg_fit": avg_fit, "critical_items": critical_items, "contract_ready": contract_ready}


def build_ai_context(data, summary, page="dashboard"):
    high_risk = [x for x in data if x["risk_level"] == "High"]
    no_backup = [x for x in data if x["backup_vendor"] == "No"]
    delayed = [x for x in data if x["delivery_status"] == "Delayed"]
    top_spend = sorted(data, key=lambda x: x["annual_spend"], reverse=True)[:3]
    critical = [x for x in data if x["formulary_status"] == "Critical"]
    return {
        "page": page,
        "summary": summary,
        "total_annual_spend": sum(x["annual_spend"] for x in data),
        "high_risk_vendors": [{"name": x["vendor_name"], "item": x["item_name"], "delivery": x["delivery_status"], "quality": x["quality_issue"], "spend": x["annual_spend"], "departments": x["affected_departments"]} for x in high_risk],
        "no_backup_vendors": [{"name": x["vendor_name"], "item": x["item_name"], "formulary": x["formulary_status"], "spend": x["annual_spend"]} for x in no_backup],
        "delayed_vendors": [{"name": x["vendor_name"], "item": x["item_name"], "lead_time": x["lead_time"]} for x in delayed],
        "top_spend_vendors": [{"name": x["vendor_name"], "item": x["item_name"], "spend": x["annual_spend"], "risk": x["risk_level"]} for x in top_spend],
        "critical_formulary": [{"name": x["vendor_name"], "item": x["item_name"], "backup": x["backup_vendor"]} for x in critical],
        "categories": list({x["item_category"] for x in data}),
        "countries": list({x["country"] for x in data}),
    }


SYSTEM_PROMPTS = {
    "exec_summary": (
        "You are a senior healthcare supply chain strategist advising a hospital system CNO and CFO. "
        "Given the vendor portfolio data, write a concise executive summary (3-4 sentences, no bullet points) "
        "that a C-suite executive would read in 15 seconds. "
        "Focus on the biggest supply risks, formulary gaps, and most urgent action. "
        "Be direct — use vendor names, item names, dollar values, and department counts. "
        "Plain sentences only. No headers, no markdown."
    ),
    "risk_analysis": (
        "You are a healthcare procurement risk analyst. "
        "Given the vendor portfolio data, provide a sharp 4-6 bullet risk analysis. "
        "Each bullet must be one sentence. Lead each with the risk type in bold (e.g. **Formulary continuity:**). "
        "Use vendor names, spend amounts, and lead times. "
        "End with one 'Immediate action:' bullet. Output only the bullets."
    ),
    "sourcing_recommendations": (
        "You are a healthcare strategic sourcing advisor. "
        "Given the vendor data and contract pipeline, produce 3 specific sourcing recommendations. "
        "Each must be one actionable sentence. Number them 1, 2, 3. "
        "Reference actual vendors, items, or spend. "
        "Focus on backup qualification, cost savings, and GPO alignment. No headers."
    ),
    "sop_actions": (
        "You are a hospital supply chain S&OP planning director. "
        "Given the supply/demand data and vendor risk posture, write 3 S&OP action statements. "
        "Each is one crisp sentence. Number them 1, 2, 3. "
        "Reference specific items, departments, or demand figures. "
        "Focus on stockout prevention, fill rate, and escalation triggers. No markdown."
    ),
    "vendor_intake": (
        "You are a healthcare procurement analyst reviewing a new vendor intake form. "
        "Given the vendor details, write a 2-sentence intake assessment: "
        "first sentence on clinical fit and regulatory risk, second on recommended next step. "
        "Be direct and specific using the submitted values. Plain text only."
    ),
}


@app.route("/api/ai-insight", methods=["POST"])
def ai_insight():
    import urllib.request
    body = request.get_json(force=True)
    context = body.get("context", {})
    mode = body.get("mode", "exec_summary")
    extra_prompt = body.get("prompt", "")

    system = SYSTEM_PROMPTS.get(mode, SYSTEM_PROMPTS["exec_summary"])
    user_msg = f"Data:\n{json.dumps(context, indent=2)}"
    if extra_prompt:
        user_msg += f"\n\n{extra_prompt}"

    payload = json.dumps({
        "model": "claude-sonnet-4-20250514",
        "max_tokens": 450,
        "system": system,
        "messages": [{"role": "user", "content": user_msg}],
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            text = "".join(b.get("text", "") for b in result.get("content", []) if b.get("type") == "text")
            return jsonify({"insight": text, "ok": True})
    except Exception as e:
        return jsonify({"insight": "", "ok": False, "error": str(e)}), 500


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    data = apply_filters(get_vendors(), request.args)
    summary = build_summary(data)
    filters = {k: request.args.get(k, "") for k in ["search", "category", "risk", "country", "stage"]}
    all_data = get_vendors()
    return render_template(
        "dashboard.html",
        summary=summary,
        vendors=data,
        story=build_exec_story(summary),
        chart_data=build_chart_data(data),
        filters=filters,
        countries=sorted({x["country"] for x in all_data}),
        categories=sorted({x["item_category"] for x in all_data}),
        stages=["New", "Contacted", "Quoting", "Sampling", "Review", "Approved", "Rejected"],
        insights=build_insights(data),
        ai_context=build_ai_context(data, summary, "dashboard"),
    )


@app.route("/sourcing")
def sourcing():
    data = apply_filters(get_vendors(), request.args)
    summary = build_summary(data)
    filters = {k: request.args.get(k, "") for k in ["search", "category", "risk", "country", "stage"]}
    all_data = get_vendors()
    pipeline = build_pipeline(data)
    planning = build_planning_data(data)
    return render_template(
        "sourcing.html",
        summary=summary,
        vendor_cards=build_vendor_cards(data),
        pipeline=pipeline,
        pipeline_counts={k: len(v) for k, v in pipeline.items()},
        contracts=get_contracts(),
        chart_data=build_chart_data(data),
        planning=planning,
        filters=filters,
        countries=sorted({x["country"] for x in all_data}),
        categories=sorted({x["item_category"] for x in all_data}),
        stages=["New", "Contacted", "Quoting", "Sampling", "Review", "Approved", "Rejected"],
        insights=build_insights(data),
        ai_context=build_ai_context(data, summary, "sourcing"),
    )


@app.route("/add_vendor", methods=["POST"])
def add_vendor():
    new_vendor = {
        "vendor_name": request.form.get("vendor_name", "").strip(),
        "item_name": request.form.get("item_name", "").strip(),
        "item_category": request.form.get("item_category", "").strip(),
        "country": request.form.get("country", "").strip(),
        "unit_cost": float(request.form.get("unit_cost", 0)),
        "previous_cost": float(request.form.get("previous_cost", 0)),
        "lead_time": int(request.form.get("lead_time", 0)),
        "delivery_status": request.form.get("delivery_status", "On Time"),
        "moq": int(request.form.get("moq", 0)),
        "backup_vendor": request.form.get("backup_vendor", "Yes"),
        "backup_vendor_name": request.form.get("backup_vendor_name", "").strip(),
        "quality_issue": request.form.get("quality_issue", "No"),
        "annual_spend": int(request.form.get("annual_spend", 0)),
        "affected_departments": int(request.form.get("affected_departments", 0)),
        "facility": request.form.get("facility", "").strip(),
        "owner": request.form.get("owner", "").strip(),
        "contract_expiry": request.form.get("contract_expiry", "").strip(),
        "certifications": request.form.get("certifications", "").strip(),
        "capacity_fit": request.form.get("capacity_fit", "Medium"),
        "qualification_stage": request.form.get("qualification_stage", "New"),
        "region_risk": request.form.get("region_risk", "Low"),
        "formulary_status": request.form.get("formulary_status", "Approved"),
    }
    vendors.append(new_vendor)
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        enriched = enrich(new_vendor)
        return jsonify({"ok": True, "vendor": enriched})
    return redirect(url_for("dashboard"))


@app.route("/add_contract", methods=["POST"])
def add_contract():
    contracts.append({
        "vendor_name": request.form.get("vendor_name", "").strip(),
        "item_name": request.form.get("item_name", "").strip(),
        "contract_status": request.form.get("contract_status", "Active"),
        "contracted_cost": float(request.form.get("contracted_cost", 0)),
        "contracted_lead": int(request.form.get("contracted_lead", 0)),
        "gpo_aligned": request.form.get("gpo_aligned", "No"),
    })
    return redirect(url_for("sourcing"))


@app.route("/seed", methods=["POST"])
def seed():
    global vendors, contracts
    vendors = seed_vendors()
    contracts = seed_contracts()
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/reset", methods=["POST"])
def reset():
    vendors.clear()
    contracts.clear()
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
