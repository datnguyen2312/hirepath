# HealthSource — Healthcare Supply Intelligence Suite

An AI-powered supply chain management workspace built for hospital systems, health networks, and healthcare procurement teams. Manage medical vendor risk, monitor formulary continuity, and run GPO-aligned sourcing — in one clinical-grade workspace.

## Features

- **Executive Dashboard** — Live KPIs: vendor risk, formulary criticality, compliance score, cost opportunities
- **Sourcing Hub** — Vendor shortlist cards, qualification pipeline (Kanban), contract & GPO management
- **6-Month Demand Planning** — Supply vs. demand curves, safety stock, fill rate, stockout risk
- **AI Insights (Claude)** — Executive summaries, risk analysis, sourcing recommendations, S&OP actions
- **Vendor Intake Form** — Add vendors with AI assessment on submission
- **Risk Scoring Engine** — Automated risk level, fit score, vendor tier, and landed cost calculation

## Quick Start

```bash
pip install -r requirements.txt
python app.py
```

Visit `http://localhost:5000` — click **Load Demo Data** to populate with sample healthcare vendors.

## Pages

| Route | Description |
|---|---|
| `/` | Vendor intake form + AI assessment |
| `/dashboard` | Executive dashboard with KPIs, charts, and AI panel |
| `/sourcing` | Sourcing Hub: cards, kanban, contracts, demand planning |

## AI Setup

The app calls `https://api.anthropic.com/v1/messages` for AI insights. Set your API key in the `ANTHROPIC_API_KEY` environment variable **or** pass it via a reverse proxy that injects the header. The app uses `claude-sonnet-4-20250514`.

## Tech Stack

- **Backend**: Python / Flask
- **Frontend**: Vanilla HTML/CSS/JS + Chart.js
- **AI**: Anthropic Claude API
- **Fonts**: IBM Plex Sans + IBM Plex Mono (Google Fonts)

## Adapting

All vendor data is seeded in `seed_vendors()` in `app.py`. Risk scoring logic is in `enrich()`. AI system prompts are in `SYSTEM_PROMPTS`. Categories, formulary statuses, qualification stages — all easily modified.

## GitHub Pages / Deployment

For production deployment, set `debug=False` and use a WSGI server (Gunicorn):

```bash
gunicorn app:app -b 0.0.0.0:8000
```
